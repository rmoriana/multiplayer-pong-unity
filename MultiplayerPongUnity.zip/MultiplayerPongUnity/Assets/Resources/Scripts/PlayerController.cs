﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;

public class PlayerController : NetworkBehaviour {
    
    Text puntosJug2;
    Text puntosJug1;    

    [SyncVar(hook = "sumaPuntos")]
    int puntos=0;

	// Use this for initialization
	void Start () {
        puntosJug1 = GameObject.Find("PuntosPlayer1").GetComponent<Text>();
        puntosJug2 = GameObject.Find("PuntosPlayer2").GetComponent<Text>();
        Singleton.playersOnline++;
        if (Singleton.playersOnline == 1)
        {
            transform.position = new Vector2(-6.24f, 0);
            this.tag = "player1";
        }
        else
        {
            transform.position = new Vector2(6.24f, 0);
            this.tag = "player2";
        }
    }

    //Inputs e inicio del juego cuando hay dos jugadores conectados.
    void Update () {

        if (Singleton.playersOnline == 2 && isServer)
        {
            CmdStartGame();
        }

        if (!isLocalPlayer)
        {
            return;
        }
        if (Input.GetKey(KeyCode.W) && transform.position.y < 3) 
        {
            transform.position = new Vector2(transform.position.x, transform.position.y + 0.2f);
        }
        if (Input.GetKey(KeyCode.S) && transform.position.y > -3)
        {
            transform.position = new Vector2(transform.position.x, transform.position.y - 0.2f);
        }        

    }
        
    //Inicio del juego
    [Command]
    void CmdStartGame()
    {
        GameObject ball = Instantiate(Resources.Load("Prefabs/ball"), new Vector2(0, 0), new Quaternion(0, 0, 0, 0)) as GameObject;
        NetworkServer.Spawn(ball);
        Singleton.playersOnline = -1;
    }

    //HUD
    void sumaPuntos(int puntos)
    {

        if (this.tag == "player1")
        {            
            puntosJug1.text = puntos.ToString();
        }
        else
        {            
            puntosJug2.text = puntos.ToString();
        }      
        
    }

    //Gestion al marcar un gol
    public void gol()
    {
        puntos++;
        if(puntos == 5)
        {
            if(this.tag == "player1")
            {
                CmdWinMessage(1);
            }
            else
            {
                CmdWinMessage(2);
            }
        }
        else
        {
            CmdStartGame();
        }        
    }

    //Mensaje de victoria cuando acaba el juego
    [Command]
    void CmdWinMessage(int num)
    {
        if (num == 1)
        {
            GameObject victoryMessage = Instantiate(Resources.Load("Prefabs/player1win")) as GameObject;
            NetworkServer.Spawn(victoryMessage);
        }
        else
        {
            GameObject victoryMessage = Instantiate(Resources.Load("Prefabs/player2win")) as GameObject;
            NetworkServer.Spawn(victoryMessage);
        }
    }
}
