﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallController : MonoBehaviour {

    int boostFuerza = 0;
    public float difPos, posPlayerY, forceY, auxPos;
    bool hitRespawnP1, hitRespawnP2;

    //Inicialización. Se añade una fuerza aleatoria a la pelota.
    void Start () {

        float forceX = 0;
        float forceY = Random.Range(-75, 75);
        while (forceX == 0)
        {
            forceX = Random.Range(-1, 2);
                      
        }
        this.GetComponent<Rigidbody2D>().AddForce(new Vector2(forceX*300, forceY));    
    }

    //Las colisiones determinan lo que pasa en el juego.
    void OnCollisionEnter2D(Collision2D other)
    {
        string ObjectTag = other.gameObject.tag;
        forceY=0;
        auxPos=0;
        switch (ObjectTag)
        {
            case "player1":
                if (!hitRespawnP1)
                {
                    hitRespawnP1 = true;
                    Invoke("RespawnHitP1", 0.5f);

                    posPlayerY = GameObject.FindGameObjectWithTag("player1").transform.position.y;
                    difPos = posPlayerY - transform.position.y;

                    bounceCalculate();

                    this.GetComponent<Rigidbody2D>().velocity = Vector2.zero;
                    this.GetComponent<Rigidbody2D>().AddForce(new Vector2(300 + boostFuerza, forceY));
                    boostFuerza += 60;
                }                
                break;
            case "player2":
                if (!hitRespawnP2)
                {
                    hitRespawnP2 = true;
                    Invoke("RespawnHitP2", 0.5f);

                    posPlayerY = GameObject.FindGameObjectWithTag("player2").transform.position.y;
                    difPos = posPlayerY - transform.position.y;

                    bounceCalculate();

                    this.GetComponent<Rigidbody2D>().velocity = Vector2.zero;
                    this.GetComponent<Rigidbody2D>().AddForce(new Vector2(-300 - boostFuerza, forceY));
                    boostFuerza += 60;
                }                
                break;
            case "paredSuperior":
                this.GetComponent<Rigidbody2D>().AddForce(new Vector2(0, -300));
                break;
            case "paredInferior":
                this.GetComponent<Rigidbody2D>().AddForce(new Vector2(0, 300));
                break;
            case "golIzquierda":
                GameObject.FindGameObjectWithTag("player2").GetComponent<PlayerController>().gol();
                Destroy(this.gameObject);
                break;
            case "golDerecha":
                GameObject.FindGameObjectWithTag("player1").GetComponent<PlayerController>().gol();
                Destroy(this.gameObject);
                break;
        }
    }

    //Calculo de la posición de la pelota respecto al jugador para calcular la dirección del rebote.
    void bounceCalculate()
    {
        if (difPos > 0) //La pelota está debajo del jugador
        {
            while (auxPos < 5)
            {
                auxPos += 0.2f;
                if (difPos <= auxPos)
                {
                    forceY = -auxPos * 85;
                    break;
                }
            }
        }
        else if (difPos < 0) //La pelota está encima del jugador
        {
            while (auxPos > -5)
            {
                auxPos -= 0.2f;
                if (difPos >= auxPos)
                {
                    forceY = -auxPos * 85;
                    break;
                }
            }
        }        
    }

    void RespawnHitP1()
    {
        hitRespawnP1 = false;
    }

    void RespawnHitP2()
    {
        hitRespawnP2 = false;
    }
}
